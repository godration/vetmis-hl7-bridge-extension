/**
 * VetMIS HL7 Bridge - Popup Controller
 */
let currentSamples = [];

document.addEventListener('DOMContentLoaded', () => {
  loadStorage();
  checkActiveTab();

  // File drop & manual file input
  const dropZone = document.getElementById('drop-zone');
  const fileInput = document.getElementById('file-input');

  dropZone.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length) {
      handleFiles(e.target.files);
    }
  });

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.style.borderColor = '#0d9488';
  });
  dropZone.addEventListener('dragleave', () => {
    dropZone.style.borderColor = '#cbd5e1';
  });
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.style.borderColor = '#cbd5e1';
    if (e.dataTransfer.files.length) {
      handleFiles(e.dataTransfer.files);
    }
  });

  // Universal Folder selector (Supported by 100% of Chromium browsers)
  const folderBtn = document.getElementById('btn-select-folder');
  const folderInput = document.getElementById('folder-input');
  const refreshBtn = document.getElementById('btn-refresh-folder');

  folderBtn.addEventListener('click', () => {
    folderInput.click();
  });

  refreshBtn.addEventListener('click', () => {
    refreshBtn.style.transform = 'rotate(180deg)';
    refreshBtn.style.transition = 'transform 0.4s ease';
    setTimeout(() => { refreshBtn.style.transform = 'none'; }, 400);

    folderInput.click();
  });

  folderInput.addEventListener('change', (e) => {
    const files = e.target.files;
    if (!files || !files.length) return;

    let folderName = 'Выбранная папка';
    const firstRel = files[0].webkitRelativePath;
    if (firstRel && firstRel.includes('/')) {
      folderName = firstRel.split('/')[0];
    }

    document.getElementById('folder-path-display').innerText = folderName;
    chrome.storage.local.set({ folder_name: folderName });

    // Filter relevant files
    const relevant = Array.from(files).filter(f => {
      const n = f.name.toLowerCase();
      return n.endsWith('.hl7') || n.endsWith('.txt') || n.endsWith('.dat');
    });

    if (relevant.length === 0) {
      showNotification('В выбранной папке не найдено файлов .hl7 или .txt', 'error');
      return;
    }

    handleFiles(relevant);
    showNotification(`Загружено файлов из папки: ${relevant.length}`, 'success');
  });

  // Search input filter
  const searchInput = document.getElementById('sample-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      renderSamples();
    });
  }

  // Load sample test button
  document.getElementById('btn-load-sample').addEventListener('click', () => {
    const sample = parseHL7String(SAMPLE_HL7_TEXT, 'sample-555464.hl7');
    addSample(sample);
    showNotification('Загружен тестовый анализ: Маркиз (проба 555464)', 'success');
  });

  // Fill button
  document.getElementById('btn-fill-active-tab').addEventListener('click', fillActiveTab);

  // Clear all
  document.getElementById('btn-clear-all').addEventListener('click', () => {
    chrome.storage.local.set({ hl7_samples: [] }, () => {
      currentSamples = [];
      renderSamples();
      showNotification('Очередь анализов очищена', 'info');
    });
  });
});

function showNotification(text, type = 'info') {
  const el = document.getElementById('notification-banner');
  if (!el) return;
  el.className = 'notification-banner ' + type;
  el.innerText = text;
  el.style.display = 'block';
  setTimeout(() => {
    el.style.display = 'none';
  }, 4000);
}

function loadStorage() {
  chrome.storage.local.get(['hl7_samples', 'folder_name'], (data) => {
    currentSamples = data.hl7_samples || [];
    renderSamples();
    if (data.folder_name) {
      document.getElementById('folder-path-display').innerText = data.folder_name;
    }
  });
}

function handleFiles(files) {
  let count = 0;
  Array.from(files).forEach(file => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const buffer = event.target.result;
      let content = '';
      try {
        const utf8Decoder = new TextDecoder('utf-8', { fatal: true });
        content = utf8Decoder.decode(buffer);
      } catch (err) {
        try {
          const cpDecoder = new TextDecoder('windows-1251');
          content = cpDecoder.decode(buffer);
        } catch (e2) {
          content = '';
        }
      }

      if (content && content.includes('OBX')) {
        const parsed = parseHL7String(content, file.name);
        addSample(parsed);
        count++;
        showNotification(`Загружен анализ: ${parsed.ownerName} · ${parsed.petName} (${parsed.records.length} показ.)`, 'success');
      }
    };
    reader.readAsArrayBuffer(file);
  });
}

function capitalizeWord(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

function parseHL7String(rawText, filename = 'sample.hl7') {
  // Support CR, LF, and CRLF segment delimiters
  const lines = rawText.split(/[\r\n]+/).map(l => l.trim()).filter(Boolean);
  let sampleId = '';
  let petName = 'Кличка';
  let ownerName = 'Владелец';
  const records = [];

  for (const line of lines) {
    const fields = line.split('|');
    const seg = fields[0]?.trim().toUpperCase();

    if (seg === 'PID') {
      const raw = (fields[5] || '').trim();
      if (raw) {
        if (raw.includes('^')) {
          const caretParts = raw.split('^').map(p => p.trim()).filter(Boolean);
          if (caretParts.length >= 2) {
            ownerName = capitalizeWord(caretParts[0]);
            petName = capitalizeWord(caretParts[1]);
          } else if (caretParts.length === 1) {
            petName = capitalizeWord(caretParts[0]);
          }
        } else {
          // Format like "26 маркиз волосникова" or "волосникова маркиз"
          const words = raw
            .split(/\s+/)
            .map(w => w.trim())
            .filter(w => w && isNaN(Number(w)));

          const surnameRegex = /(ова|ева|ина|ына|ов|ев|ин|ын|ский|ская|цкий|цкая|их|ых|ко)$/i;

          if (words.length >= 2) {
            if (surnameRegex.test(words[1])) {
              // words: ["маркиз", "волосникова"]
              petName = capitalizeWord(words[0]);
              ownerName = capitalizeWord(words[1]);
            } else if (surnameRegex.test(words[0])) {
              // words: ["волосникова", "маркиз"]
              ownerName = capitalizeWord(words[0]);
              petName = capitalizeWord(words[1]);
            } else {
              petName = capitalizeWord(words[0]);
              ownerName = capitalizeWord(words.slice(1).join(' '));
            }
          } else if (words.length === 1) {
            if (surnameRegex.test(words[0])) {
              ownerName = capitalizeWord(words[0]);
            } else {
              petName = capitalizeWord(words[0]);
            }
          }
        }
      }
    } else if (seg === 'OBR') {
      sampleId = (fields[3] || fields[2] || '').trim();
    } else if (seg === 'OBX') {
      const name = (fields[4] || '').trim();
      const rawVal = (fields[5] || '0').trim();
      const unit = (fields[6] || '').trim();
      const numVal = parseFloat(rawVal.replace(',', '.'));

      if (name) {
        records.push({
          name,
          value: isNaN(numVal) ? 0 : numVal,
          rawValue: rawVal,
          unit
        });
      }
    }
  }

  // Fallback sample ID from filename only if OBR-3 was empty
  if (!sampleId) {
    const m = filename.match(/\d{5,8}/);
    if (m) sampleId = m[0];
  }

  return {
    id: 's_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
    sampleId: sampleId || 'Б/Н',
    petName: petName,
    ownerName: ownerName,
    records,
    createdAt: new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })
  };
}

function addSample(sample) {
  const existingIdx = currentSamples.findIndex(s => s.sampleId === sample.sampleId && s.sampleId !== 'Б/Н');
  if (existingIdx >= 0) {
    currentSamples[existingIdx] = sample;
  } else {
    currentSamples.unshift(sample);
  }

  // Keep up to 100 latest samples automatically
  if (currentSamples.length > 100) {
    currentSamples = currentSamples.slice(0, 100);
  }

  chrome.storage.local.set({ hl7_samples: currentSamples }, () => {
    renderSamples();
  });
}

function renderSamples() {
  const list = document.getElementById('samples-list');
  const countSpan = document.getElementById('samples-count');
  if (!list) return;

  const searchQuery = (document.getElementById('sample-search-input')?.value || '').trim().toLowerCase();

  const filteredSamples = currentSamples.filter(sample => {
    if (!searchQuery) return true;
    const owner = (sample.ownerName || '').toLowerCase();
    const pet = (sample.petName || '').toLowerCase();
    const sampleId = String(sample.sampleId || '').toLowerCase();
    return owner.includes(searchQuery) || pet.includes(searchQuery) || sampleId.includes(searchQuery);
  });

  countSpan.innerText = String(filteredSamples.length) + (searchQuery ? (' / ' + currentSamples.length) : '');

  if (!filteredSamples.length) {
    const emptyMsg = searchQuery ? ('Пациенты не найдены по запросу "' + searchQuery + '"') : 'Нет загруженных файлов. Выберите папку с анализами выше.';
    list.innerHTML = '<div style="color:#94a3b8; text-align:center; padding:16px; font-size:12px;">' + emptyMsg + '</div>';
    return;
  }

  list.innerHTML = '';
  filteredSamples.forEach((sample, index) => {
    const card = document.createElement('div');
    card.className = 'sample-card' + (index === 0 && !searchQuery ? ' active' : '');
    card.innerHTML = `
      <div class="sample-info">
        <strong>${sample.ownerName || 'Владелец'} · ${sample.petName || 'Кличка'}</strong>
        <div class="sample-meta">Проба №${sample.sampleId} · ${sample.records?.length || 0} показ. · ${sample.createdAt || ''}</div>
      </div>
      <div class="sample-actions">
        <button class="btn-sm-action fill-btn" data-id="${sample.id}">Вставить</button>
      </div>
    `;

    card.querySelector('.fill-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      executeFill(sample);
    });

    list.appendChild(card);
  });
}

function checkActiveTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]?.id) return;
    chrome.tabs.sendMessage(tabs[0].id, { action: 'PING_MIS_PAGE' }, (response) => {
      const patientEl = document.getElementById('current-patient-detected');
      if (chrome.runtime.lastError || !response) {
        patientEl.innerText = 'МИС: страница протокола не обнаружена';
        return;
      }

      if (response.isMisPage) {
        patientEl.innerHTML = `МИС: <strong>${response.patientName || 'Документ открыт'}</strong> (${response.hasLabTable ? 'таблица БХ готова' : 'нет таблицы'})`;
        document.getElementById('status-badge').innerText = 'МИС готова';
        document.getElementById('status-badge').style.background = '#059669';
      }
    });
  });
}

function fillActiveTab() {
  if (!currentSamples.length) {
    showNotification('Сначала загрузите хотя бы один файл анализа HL7.', 'error');
    return;
  }
  executeFill(currentSamples[0]);
}

function executeFill(sample) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]?.id) return;
    chrome.storage.local.get(['settings'], (s) => {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'FILL_PROTOCOL',
        sample,
        settings: s.settings || {}
      }, (res) => {
        if (chrome.runtime.lastError || !res) {
          showNotification('Не удалось внести: убедитесь, что открыт протокол в МИС Renovatio', 'error');
          return;
        }

        if (res.success) {
          showNotification(`✓ Успешно внесено показателей: ${res.filledCount}! Нажмите «Сохранить» в МИС.`, 'success');
        } else {
          showNotification('Ошибка: ' + (res.error || 'неизвестная ошибка'), 'error');
        }
      });
    });
  });
}

const SAMPLE_HL7_TEXT = `MSH|^~\&|||||20260609182224||ORU^R01|156|P|2.3.1||||0||ASCII|||
PID|113||||26 маркиз волосникова|||O|||||||||||||||||||||||
OBR|113||555464|^|N|20260609171303|20260609171235|20260609171235||1^37||||20260609171235|Сывор|||||||||||||||||||||||||||||||||
OBX|1|NM||Calcium|2.578445|mmol/L|-|N|||F||2.578445|20260609180948|||0|
OBX|2|NM||Bilirubin Total (DSA Method)|-0.484812|?mol/L|-|N|||F||-0.484812|20260609181754|||0|
OBX|3|NM||Alkaline phosphatase|45.320590|U/L|-|N|||F||45.320590|20260609181248|||0|
OBX|4|NM||Gamma-Glutamyltransferase|-0.670611|U/L|-|N|||F||-0.670611|20260609181306|||0|
OBX|5|NM||Albumin|41.560684|g/L|-|N|||F||41.560684|20260609181154|||0|
OBX|6|NM||Creatinine (Sarcosine Oxidase Method)|113.986629|?mol/L|-|N|||F||113.986629|20260609181848|||0|
OBX|7|NM||Urea|8.305894|mmol/L|-|N|||F||8.305894|20260609181418|||0|
OBX|8|NM||Creatine Kinase|394.744937|U/L|-|N|||F||394.744937|20260609181718|||0|
OBX|9|NM||Холестерин|3.602124|mmol/L|-|N|||F||3.602124|20260609181512|||0|
OBX|10|NM||Билирубин общий|11.362884|?mol/L|-|N|||F||11.362884|20260609182224|||0|
OBX|11|NM||Триглицериды|1.055013|mmol/L|-|N|||F||1.055013|20260609181548|||0|
OBX|12|NM||АЛТ|78.611343|U/L|-|N|||F||78.611343|20260609181436|||0|
OBX|13|NM||АСТ|64.914242|U/L|-|N|||F||64.914242|20260609181512|||0|
OBX|14|NM||Tot pr|86.345816|g/L|-|N|||F||86.345816|20260609181906|||0|
OBX|15|NM||Phosphorus|1.294986|mmol/L|-|N|||F||1.294986|20260609181830|||0|
OBX|16|NM||B/C|38.735400||-|N|||F||38.735400|||||
`;
