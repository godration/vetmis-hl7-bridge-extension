/**
 * VetMIS HL7 Bridge - Mapping Rules & Biochemical Markers
 */
const DEFAULT_RULES = [
  {
    "misName": "Аланинаминотрасфераза",
    "standardName": "ALT",
    "aliases": [
      "АЛТ",
      "ALT",
      "ALAT",
      "SGPT",
      "Alanine aminotransferase"
    ],
    "unit": "МЕ/л",
    "normalRange": "10.0-100.0",
    "roundingDecimals": 1,
    "category": "enzymes",
    "description": "Аланинаминотрансфераза (фермент печени)"
  },
  {
    "misName": "Аспартатаминотрансфераза",
    "standardName": "AST",
    "aliases": [
      "АСТ",
      "AST",
      "ASAT",
      "SGOT",
      "Aspartate aminotransferase"
    ],
    "unit": "МЕ/л",
    "normalRange": "10.0-50.0",
    "roundingDecimals": 1,
    "category": "enzymes",
    "description": "Аспартатаминотрансфераза"
  },
  {
    "misName": "Билирубин общий",
    "standardName": "TBIL",
    "aliases": [
      "Билирубин общий",
      "Bilirubin Total",
      "T-BIL",
      "TBIL",
      "Total Bilirubin"
    ],
    "unit": "мкмоль/л",
    "normalRange": "0.0-8.0",
    "roundingDecimals": 2,
    "category": "substrates",
    "description": "Общий билирубин"
  },
  {
    "misName": "Креатинин",
    "standardName": "CREA",
    "aliases": [
      "Креатинин",
      "Creatinine",
      "CREA",
      "CREAT",
      "Creatinine (Sarcosine Oxidase Method)"
    ],
    "unit": "мкмоль/л",
    "normalRange": "50.0-130.0",
    "roundingDecimals": 1,
    "category": "substrates",
    "description": "Креатинин сыворотки"
  },
  {
    "misName": "Мочевина",
    "standardName": "UREA",
    "aliases": [
      "Мочевина",
      "Urea",
      "BUN",
      "UREA/BUN",
      "Carbamide"
    ],
    "unit": "ммоль/л",
    "normalRange": "4.0-8.0",
    "roundingDecimals": 2,
    "category": "substrates",
    "description": "Мочевина"
  },
  {
    "misName": "Общий белок",
    "standardName": "TP",
    "aliases": [
      "Общий белок",
      "Tot pr",
      "TP",
      "Total Protein",
      "T-PROT",
      "Белок общий"
    ],
    "unit": "г/л",
    "normalRange": "60.0-80.0",
    "roundingDecimals": 1,
    "category": "proteins",
    "description": "Общий белок сыворотки"
  },
  {
    "misName": "Альбумин",
    "standardName": "ALB",
    "aliases": [
      "Альбумин",
      "Albumin",
      "ALB",
      "Alb"
    ],
    "unit": "г/л",
    "normalRange": "25.0-40.0",
    "roundingDecimals": 1,
    "category": "proteins",
    "description": "Альбумин сыворотки"
  },
  {
    "misName": "Глобулины",
    "standardName": "GLOB",
    "aliases": [
      "Глобулины",
      "Globulin",
      "GLOB",
      "Глобулин"
    ],
    "unit": "г/л",
    "normalRange": "35.0-40.0",
    "roundingDecimals": 1,
    "isCalculated": true,
    "formula": "total_protein - albumin",
    "category": "proteins",
    "description": "Рассчитывается: Общий белок - Альбумин"
  },
  {
    "misName": "Альбумин-глобулиновое соотношение",
    "standardName": "AGR",
    "aliases": [
      "Альбумин-глобулиновое соотношение",
      "A/G",
      "A/G ratio",
      "AG Ratio",
      "А/Г",
      "B/C"
    ],
    "unit": "-",
    "normalRange": "0.6-1.5",
    "roundingDecimals": 2,
    "isCalculated": true,
    "formula": "albumin / globulin",
    "category": "proteins",
    "description": "Рассчитывается: Альбумин / Глобулины"
  },
  {
    "misName": "Кальций",
    "standardName": "CA",
    "aliases": [
      "Кальций",
      "Кальций общий",
      "Calcium",
      "Ca",
      "Total Calcium"
    ],
    "unit": "ммоль/л",
    "normalRange": "2.3-3.0",
    "roundingDecimals": 2,
    "category": "electrolytes",
    "description": "Общий кальций сыворотки"
  },
  {
    "misName": "Ионизированный кальций",
    "standardName": "ICA",
    "aliases": [
      "Ионизированный кальций",
      "iCa",
      "Ionized Calcium",
      "Ca++"
    ],
    "unit": "ммоль/л",
    "normalRange": "1.13-1.38",
    "roundingDecimals": 2,
    "category": "electrolytes",
    "description": "Ионизированный кальций (iCa)"
  },
  {
    "misName": "Фосфор",
    "standardName": "PHOS",
    "aliases": [
      "Фосфор",
      "Phosphorus",
      "PHOS",
      "Inorganic Phosphorus",
      "P"
    ],
    "unit": "ммоль/л",
    "normalRange": "0.9-2.0",
    "roundingDecimals": 2,
    "category": "electrolytes",
    "description": "Неорганический фосфор"
  },
  {
    "misName": "Щёлочная фосфатаза",
    "standardName": "ALP",
    "aliases": [
      "Щёлочная фосфатаза",
      "Щелочная фосфатаза",
      "Alkaline phosphatase",
      "ALP",
      "ALKP",
      "ЩФ"
    ],
    "unit": "МЕ/л",
    "normalRange": "4.0-60.0",
    "roundingDecimals": 1,
    "category": "enzymes",
    "description": "Щелочная фосфатаза"
  },
  {
    "misName": "Гаммаглутамилтрансфераза",
    "standardName": "GGT",
    "aliases": [
      "Гаммаглутамилтрансфераза",
      "Гамма-глутамилтрансфераза",
      "Gamma-Glutamyltransferase",
      "GGT",
      "GGTP",
      "ГГТ"
    ],
    "unit": "МЕ/л",
    "normalRange": "0.0-3.0",
    "roundingDecimals": 1,
    "category": "enzymes",
    "description": "ГГТ (гамма-глутамилтранспептидаза)"
  },
  {
    "misName": "Креатинкиназа",
    "standardName": "CK",
    "aliases": [
      "Креатинкиназа",
      "Креатинин киназа",
      "Creatine Kinase",
      "CK",
      "CPK",
      "КФК"
    ],
    "unit": "МЕ/л",
    "normalRange": "0.0-600.0",
    "roundingDecimals": 1,
    "category": "enzymes",
    "description": "Креатинфосфокиназа"
  },
  {
    "misName": "Холестерин",
    "standardName": "CHOL",
    "aliases": [
      "Холестерин",
      "Cholesterol",
      "CHOL",
      "Холестерол",
      "TC"
    ],
    "unit": "ммоль/л",
    "normalRange": "2.3-6.0",
    "roundingDecimals": 2,
    "category": "lipids",
    "description": "Общий холестерин"
  },
  {
    "misName": "Триглицериды",
    "standardName": "TRIG",
    "aliases": [
      "Триглицериды",
      "Triglycerides",
      "TRIG",
      "TG"
    ],
    "unit": "ммоль/л",
    "normalRange": "0.0-1.5",
    "roundingDecimals": 2,
    "category": "lipids",
    "description": "Триглицериды"
  },
  {
    "misName": "Глюкоза",
    "standardName": "GLU",
    "aliases": [
      "Глюкоза",
      "Glucose",
      "GLU",
      "GLUC"
    ],
    "unit": "ммоль/л",
    "normalRange": "3.5-7.5",
    "roundingDecimals": 2,
    "category": "substrates",
    "description": "Глюкоза в сыворотке"
  },
  {
    "misName": "Натрий",
    "standardName": "NA",
    "aliases": [
      "Натрий",
      "Sodium",
      "Na",
      "Na+"
    ],
    "unit": "ммоль/л",
    "normalRange": "144.0-159.0",
    "roundingDecimals": 1,
    "category": "electrolytes",
    "description": "Ионы натрия"
  },
  {
    "misName": "Калий",
    "standardName": "K",
    "aliases": [
      "Калий",
      "Potassium",
      "K",
      "K+"
    ],
    "unit": "ммоль/л",
    "normalRange": "3.2-5.5",
    "roundingDecimals": 2,
    "category": "electrolytes",
    "description": "Ионы калия"
  },
  {
    "misName": "Хлориды",
    "standardName": "CL",
    "aliases": [
      "Хлориды",
      "Chloride",
      "Cl",
      "Cl-",
      "Хлор"
    ],
    "unit": "ммоль/л",
    "normalRange": "109.0-126.0",
    "roundingDecimals": 1,
    "category": "electrolytes",
    "description": "Хлориды"
  },
  {
    "misName": "Соотношение Na/K",
    "standardName": "NA_K_RATIO",
    "aliases": [
      "Соотношение Na/K",
      "Na/K",
      "Na/K ratio",
      "Соотношение натрий/калий"
    ],
    "unit": "-",
    "normalRange": ">27:1",
    "roundingDecimals": 2,
    "isCalculated": true,
    "formula": "sodium / potassium",
    "category": "electrolytes",
    "description": "Рассчитывается: Натрий / Калий"
  },
  {
    "misName": "Амилаза",
    "standardName": "AMYL",
    "aliases": [
      "Амилаза",
      "Альфа-амилаза",
      "Amylase",
      "AMY",
      "AMYL"
    ],
    "unit": "МЕ/л",
    "normalRange": "500-1500",
    "roundingDecimals": 0,
    "category": "enzymes",
    "description": "Альфа-амилаза"
  },
  {
    "misName": "Магний",
    "standardName": "MG",
    "aliases": [
      "Магний",
      "Magnesium",
      "Mg"
    ],
    "unit": "ммоль/л",
    "normalRange": "0.8-1.2",
    "roundingDecimals": 2,
    "category": "electrolytes",
    "description": "Магний"
  }
];

function cleanMarkerName(str) {
  if (!str) return '';
  const clean = str
    .replace(/\(.*?\)/g, '')
    .replace(/,\s*(ме\/л|мкмоль\/л|ммоль\/л|г\/л|%|u\/l|mmol\/l|umol\/l|g\/l|\?mol\/l).*/i, '')
    .trim();
  return clean.toLowerCase().replace(/[ё]/g, 'е').replace(/[^a-zа-я0-9]/g, '');
}

const normalizeText = cleanMarkerName;

function matchMarker(hl7Name, rules = DEFAULT_RULES) {
  if (!hl7Name) return null;
  const norm = cleanMarkerName(hl7Name);

  // 1. Exact match
  for (const rule of rules) {
    if (cleanMarkerName(rule.misName) === norm) return rule;
    if (cleanMarkerName(rule.standardName) === norm) return rule;
    for (const alias of rule.aliases) {
      if (cleanMarkerName(alias) === norm) return rule;
    }
  }

  // 2. Word / prefix / substring match
  for (const rule of rules) {
    const misNorm = cleanMarkerName(rule.misName);
    if (misNorm.length >= 3 && (norm.includes(misNorm) || misNorm.includes(norm))) {
      return rule;
    }
    for (const alias of rule.aliases) {
      const aNorm = cleanMarkerName(alias);
      if (aNorm.length >= 3 && (norm.includes(aNorm) || aNorm.includes(norm))) {
        return rule;
      }
    }
  }
  return null;
}
