/**
 * VetMIS HL7 Bridge - Content Script
 * Injected on Renovatio MIS pages (/patients/documents/update/id/...)
 */
(function () {
  console.log('[VetMIS HL7 Bridge] Content script активен');

  // Listen for messages from popup
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'PING_MIS_PAGE') {
      const table = document.querySelector('.med-doc-table-lab');
      const patientCard = document.querySelector('.profile-top__name');
      const docTitle = document.querySelector('#PatientDocument_title')?.value || '';
      sendResponse({
        isMisPage: true,
        hasLabTable: !!table,
        documentTitle: docTitle,
        patientName: patientCard?.innerText?.trim() || ''
      });
      return true;
    }

    if (msg.action === 'FILL_PROTOCOL') {
      const result = fillProtocolWithHL7(msg.sample, msg.settings);
      sendResponse(result);
      return true;
    }
  });

  // Inject floating quick widget if on document page
  if (window.location.href.includes('/patients/documents/') || document.querySelector('.med-doc-table-lab')) {
    initFloatingWidget();
  }

  function fillProtocolWithHL7(sample, settings = {}) {
    if (!sample || !sample.records || !sample.records.length) {
      return { success: false, error: 'В выбранном анализе нет показателей (0 OBX записей).' };
    }

    const labInputs = document.querySelectorAll('input.med-doc-lab-value, table.med-doc-table-lab input');
    if (!labInputs.length) {
      return { success: false, error: 'Поля лабораторного протокола (.med-doc-lab-value) не найдены. Убедитесь, что открыт режим редактирования протокола в МИС.' };
    }

    const rows = document.querySelectorAll('table.med-doc-table-lab tr, .med-doc-wrap tr');
    let filledCount = 0;
    const filledFields = [];
    const valuesByStd = {};

    // 1. Fill direct matched markers
    rows.forEach(tr => {
      const cells = tr.querySelectorAll('td');
      if (cells.length < 2) return;

      const titleCell = cells[0];
      const input = tr.querySelector('input.med-doc-lab-value, input[type="text"]');
      if (!input || !titleCell) return;

      const misTitle = titleCell.innerText.trim();
      const matchedRule = matchMarker(misTitle);

      if (!matchedRule) return;

      // Find record in sample
      const record = sample.records.find(r => {
        if (r.name && r.name.includes('DSA Method')) return false;
        const rRule = matchMarker(r.name);
        return rRule && rRule.standardName === matchedRule.standardName;
      });

      if (record) {
        let val = record.value;

        // Special handling for GGT negative noise values
        if (matchedRule.standardName === 'GGT' && val < 0) {
          val = 0.1;
        }

        // Don't auto-fill total calcium into ionized calcium field
        if (record.code && record.code.toLowerCase() === 'calcium' && misTitle.toLowerCase().includes('ионизированный')) {
          return;
        }

        // Apply rounding
        const decimals = settings.roundingMode === 'decimals_1' ? 1 :
                         settings.roundingMode === 'decimals_2' ? 2 :
                         matchedRule.roundingDecimals ?? 2;

        const formatted = Number(val).toFixed(decimals).replace('.', ',');
        input.value = formatted;

        // Dispatch events for Renovatio reactive framework
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));

        // Highlight
        if (settings.highlightFilledFields !== false) {
          input.classList.add('vetmis-field-highlight');
          setTimeout(() => input.classList.remove('vetmis-field-highlight'), 2500);
        }

        valuesByStd[matchedRule.standardName] = Number(val);
        filledCount++;
        filledFields.push({ name: misTitle, value: formatted });
      }
    });

    // 2. Compute calculated fields (Globulin, A/G ratio, Na/K ratio)
    rows.forEach(tr => {
      const cells = tr.querySelectorAll('td');
      if (cells.length < 2) return;
      const titleCell = cells[0];
      const input = cells[1]?.querySelector('input.med-doc-lab-value');
      if (!input || !titleCell) return;

      const misTitle = titleCell.innerText.trim();
      const norm = normalizeText(misTitle);

      // Globulin: TP - ALB
      if (norm.includes('глобулин') && !norm.includes('соотношение')) {
        const tp = valuesByStd['TP'];
        const alb = valuesByStd['ALB'];
        if (tp !== undefined && alb !== undefined) {
          const glob = Math.max(0, tp - alb);
          valuesByStd['GLOB'] = glob;
          const formatted = glob.toFixed(1).replace('.', ',');
          input.value = formatted;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          input.classList.add('vetmis-field-highlight');
          setTimeout(() => input.classList.remove('vetmis-field-highlight'), 2500);
          filledCount++;
          filledFields.push({ name: 'Глобулины (расчёт)', value: formatted });
        }
      }

      // A/G Ratio: ALB / GLOB
      if (norm.includes('альбуминглобулин') || norm.includes('агсоотношение') || norm.includes('аг')) {
        const alb = valuesByStd['ALB'];
        const glob = valuesByStd['GLOB'];
        if (alb !== undefined && glob && glob > 0) {
          const ag = alb / glob;
          const formatted = ag.toFixed(2).replace('.', ',');
          input.value = formatted;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          input.classList.add('vetmis-field-highlight');
          setTimeout(() => input.classList.remove('vetmis-field-highlight'), 2500);
          filledCount++;
          filledFields.push({ name: 'А/Г соотношение (расчёт)', value: formatted });
        }
      }

      // Na/K Ratio: NA / K
      if (norm.includes('соотношениеnak') || norm.includes('nak')) {
        const na = valuesByStd['NA'];
        const k = valuesByStd['K'];
        if (na !== undefined && k && k > 0) {
          const ratio = na / k;
          const formatted = ratio.toFixed(2).replace('.', ',');
          input.value = formatted;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          input.classList.add('vetmis-field-highlight');
          setTimeout(() => input.classList.remove('vetmis-field-highlight'), 2500);
          filledCount++;
          filledFields.push({ name: 'Соотношение Na/K (расчёт)', value: formatted });
        }
      }
    });

    return {
      success: true,
      filledCount,
      filledFields
    };
  }

  function initFloatingWidget() {
    const old = document.getElementById('vetmis-quick-widget');
    if (old) old.remove();

    const widget = document.createElement('div');
    widget.id = 'vetmis-quick-widget';
    widget.className = 'vetmis-hl7-widget';

    // Restore saved position if physician moved widget
    const savedLeft = localStorage.getItem('vetmis_widget_left');
    const savedTop = localStorage.getItem('vetmis_widget_top');
    if (savedLeft && savedTop) {
      widget.style.left = savedLeft + 'px';
      widget.style.top = savedTop + 'px';
      widget.style.bottom = 'auto';
      widget.style.right = 'auto';
    }

    widget.innerHTML = `
      <div class="vetmis-hl7-header" id="vetmis-widget-header">
        <strong>🖐 HL7 Bridge</strong>
        <div class="vetmis-widget-actions">
          <button class="vetmis-widget-btn" id="vetmis-btn-minimize" title="Свернуть в мини-значок">—</button>
          <button class="vetmis-widget-btn" id="vetmis-btn-close" title="Скрыть">✕</button>
        </div>
      </div>
      <div class="vetmis-hl7-body" id="vetmis-widget-body">
        <div style="margin-bottom:8px;">
          <input type="text" id="vetmis-widget-search" placeholder="🔍 Поиск по фамилии, кличке или №..." style="width:100%; padding:5px 8px; border:1px solid #cbd5e1; border-radius:6px; font-size:11px; outline:none;" />
        </div>
        <div id="vetmis-samples-container" style="max-height:280px; overflow-y:auto;">Загрузка очереди...</div>
      </div>
    `;

    document.body.appendChild(widget);

    const header = widget.querySelector('#vetmis-widget-header');
    const body = widget.querySelector('#vetmis-widget-body');
    const btnMin = widget.querySelector('#vetmis-btn-minimize');
    const btnClose = widget.querySelector('#vetmis-btn-close');
    const searchInput = widget.querySelector('#vetmis-widget-search');

    // Make Widget Draggable anywhere on screen
    let isDragging = false;
    let startX = 0, startY = 0;
    let initialLeft = 0, initialTop = 0;

    header.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON' || e.target.tagName === 'INPUT') return;
      isDragging = true;
      const rect = widget.getBoundingClientRect();
      startX = e.clientX;
      startY = e.clientY;
      initialLeft = rect.left;
      initialTop = rect.top;
      header.style.cursor = 'grabbing';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const deltaX = e.clientX - startX;
      const deltaY = e.clientY - startY;
      const newLeft = Math.max(10, Math.min(window.innerWidth - 80, initialLeft + deltaX));
      const newTop = Math.max(10, Math.min(window.innerHeight - 40, initialTop + deltaY));

      widget.style.left = newLeft + 'px';
      widget.style.top = newTop + 'px';
      widget.style.bottom = 'auto';
      widget.style.right = 'auto';

      localStorage.setItem('vetmis_widget_left', newLeft);
      localStorage.setItem('vetmis_widget_top', newTop);
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        header.style.cursor = 'move';
      }
    });

    // Minimize / Expand logic
    let isMinimized = localStorage.getItem('vetmis_widget_minimized') === 'true';

    function applyMinState() {
      if (isMinimized) {
        body.style.display = 'none';
        btnMin.innerText = '□';
        widget.classList.add('minimized');
      } else {
        body.style.display = 'block';
        btnMin.innerText = '—';
        widget.classList.remove('minimized');
      }
    }

    applyMinState();

    btnMin.addEventListener('click', (e) => {
      e.stopPropagation();
      isMinimized = !isMinimized;
      localStorage.setItem('vetmis_widget_minimized', isMinimized);
      applyMinState();
    });

    btnClose.addEventListener('click', (e) => {
      e.stopPropagation();
      widget.style.display = 'none';
    });

    // Render Widget Samples List (Up to 100)
    function renderWidgetSamples() {
      chrome.storage.local.get(['hl7_samples', 'settings'], (res) => {
        const container = widget.querySelector('#vetmis-samples-container');
        const samples = res.hl7_samples || [];
        const settings = res.settings || {};
        const query = (searchInput?.value || '').trim().toLowerCase();

        const filtered = samples.filter(s => {
          if (!query) return true;
          const owner = (s.ownerName || '').toLowerCase();
          const pet = (s.petName || '').toLowerCase();
          const sampleId = String(s.sampleId || '').toLowerCase();
          return owner.includes(query) || pet.includes(query) || sampleId.includes(query);
        });

        if (!filtered.length) {
          const msg = query ? 'Не найдено' : 'Очередь анализов пуста';
          container.innerHTML = '<div style="color:#94a3b8; font-style:italic; font-size:11px; padding:10px; text-align:center;">' + msg + '</div>';
          return;
        }

        container.innerHTML = '';
        filtered.slice(0, 100).forEach(sample => {
          const item = document.createElement('div');
          item.className = 'vetmis-hl7-sample-item';
          item.innerHTML = `
            <div style="font-weight:700; color:#0f766e; font-size:12px;">${sample.ownerName || 'Владелец'} · ${sample.petName || 'Кличка'}</div>
            <div style="font-size:11px; color:#64748b; margin-top:2px;">Проба №${sample.sampleId} · ${sample.records?.length || 0} показателей</div>
            <button class="vetmis-hl7-btn">⚡ Вставить в бланк</button>
          `;

          const btn = item.querySelector('button');
          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const res = fillProtocolWithHL7(sample, settings);
            if (res.success) {
              btn.innerText = '✓ Внесено: ' + res.filledCount + ' показ.';
              btn.style.background = '#059669';
            } else {
              alert('Ошибка внесения: ' + (res.error || 'проверьте бланк'));
            }
          });

          container.appendChild(item);
        });
      });
    }

    renderWidgetSamples();

    if (searchInput) {
      searchInput.addEventListener('input', renderWidgetSamples);
    }
  }
})();
