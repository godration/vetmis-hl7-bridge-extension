/**
 * VetMIS HL7 Bridge - Service Worker (Manifest V3)
 */
chrome.runtime.onInstalled.addListener(() => {
  console.log('[VetMIS HL7 Bridge] Установлено расширение');
  chrome.storage.local.get(['hl7_samples', 'settings'], (data) => {
    if (!data.hl7_samples) {
      chrome.storage.local.set({ hl7_samples: [] });
    }
    if (!data.settings) {
      chrome.storage.local.set({
        settings: {
          roundingMode: 'decimals_2',
          autoCalculateGlobulin: true,
          autoCalculateAgRatio: true,
          autoCalculateNaKRatio: true,
          highlightFilledFields: true
        }
      });
    }
  });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'UPDATE_BADGE') {
    const count = request.count || 0;
    chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#0d9488' });
    sendResponse({ success: true });
  }
  return true;
});
